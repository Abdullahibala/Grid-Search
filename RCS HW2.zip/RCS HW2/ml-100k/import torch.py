import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error

# ---------------------------
# LOAD MOVIELENS DATASET
# ---------------------------
def load_movielens(path="ratings.csv"):
    """
    Expects the MovieLens ratings.csv file.
    """
    df = pd.read_csv(path)
    df = df[["userId", "movieId", "rating"]]

    # Encode IDs to be sequential
    df["userId"] = df["userId"].astype("category").cat.codes
    df["movieId"] = df["movieId"].astype("category").cat.codes

    n_users = df.userId.max() + 1
    n_items = df.movieId.max() + 1

    train, test = train_test_split(df, test_size=0.2, random_state=42)

    return train, test, n_users, n_items


# ---------------------------
# MATRIX FACTORIZATION MODEL
# ---------------------------
class MF(nn.Module):
    def __init__(self, num_users, num_items, embed_dim):
        super(MF, self).__init__()
        self.user_emb = nn.Embedding(num_users, embed_dim)
        self.item_emb = nn.Embedding(num_items, embed_dim)

        self.user_bias = nn.Embedding(num_users, 1)
        self.item_bias = nn.Embedding(num_items, 1)

    def forward(self, user, item):
        u = self.user_emb(user)
        i = self.item_emb(item)
        dot = (u * i).sum(1)
        return dot + self.user_bias(user).squeeze() + self.item_bias(item).squeeze()


# ---------------------------
# TRAINING FUNCTION
# ---------------------------
def train_model(model, train_df, test_df, lr, weight_decay, epochs=5):
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = nn.MSELoss()

    # Convert data to tensors
    users_train = torch.tensor(train_df.userId.values).long()
    items_train = torch.tensor(train_df.movieId.values).long()
    ratings_train = torch.tensor(train_df.rating.values).float()

    users_test = torch.tensor(test_df.userId.values).long()
    items_test = torch.tensor(test_df.movieId.values).long()
    ratings_test = torch.tensor(test_df.rating.values).float()

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        preds = model(users_train, items_train)
        loss = criterion(preds, ratings_train)
        loss.backward()
        optimizer.step()

    # Compute test RMSE and MAE
    model.eval()
    preds_test = model(users_test, items_test).detach().numpy()
    rmse = np.sqrt(mean_squared_error(ratings_test, preds_test))
    mae = mean_absolute_error(ratings_test, preds_test)

    return rmse, mae


# ---------------------------
# GRID SEARCH
# ---------------------------
def grid_search(train, test, n_users, n_items):

    embed_sizes = [8, 16, 32]
    learning_rates = [0.001, 0.01, 0.1]
    regs = [0.0, 0.001, 0.01]

    results = []

    for e in embed_sizes:
        for lr in learning_rates:
            for reg in regs:

                model = MF(n_users, n_items, e)
                rmse, mae = train_model(model, train, test, lr, reg)

                results.append((e, lr, reg, rmse, mae))
                print(f"embed={e}, lr={lr}, reg={reg} → RMSE={rmse:.4f}, MAE={mae:.4f}")

    # find best by RMSE
    results.sort(key=lambda x: x[3])
    best = results[0]

    print("\nBEST PARAMETER COMBINATION (lowest RMSE)")
    print(f"Embedding={best[0]} | LR={best[1]} | Reg={best[2]}")
    print(f"RMSE={best[3]:.4f}, MAE={best[4]:.4f}")

    return results, best


# ---------------------------
# MAIN EXECUTION
# ---------------------------
if __name__ == "__main__":
    # Ensure the downloaded MovieLens file is named "ratings.csv"
    train, test, n_users, n_items = load_movielens("ratings.csv")

    results, best = grid_search(train, test, n_users, n_items)
