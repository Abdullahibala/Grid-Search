import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


# -------------------------------
# Load MovieLens dataset
# -------------------------------
def load_movielens(path):
    df = pd.read_csv(path, sep="\t", names=["userId", "movieId", "rating", "timestamp"])

    users = df["userId"].max() + 1
    items = df["movieId"].max() + 1

    # 80/20 split
    msk = (df.index % 5) != 0
    train_df = df[msk]
    test_df = df[~msk]

    return train_df, test_df, users, items


# -------------------------------
# PyTorch Dataset
# -------------------------------
class RatingsDataset(Dataset):
    def __init__(self, df):
        self.users = torch.tensor(df["userId"].values, dtype=torch.long)
        self.items = torch.tensor(df["movieId"].values, dtype=torch.long)
        self.ratings = torch.tensor(df["rating"].values, dtype=torch.float32)

    def __len__(self):
        return len(self.ratings)

    def __getitem__(self, idx):
        return self.users[idx], self.items[idx], self.ratings[idx]


# -------------------------------
# Matrix Factorization Model
# -------------------------------
class MF(nn.Module):
    def __init__(self, n_users, n_items, embed_dim=8, reg=0.001):
        super().__init__()
        self.user_embed = nn.Embedding(n_users, embed_dim)
        self.item_embed = nn.Embedding(n_items, embed_dim)
        self.reg = reg

    def forward(self, user, item):
        u = self.user_embed(user)
        v = self.item_embed(item)
        return (u * v).sum(1)

    def l2_regularization(self):
        return self.reg * (
            self.user_embed.weight.norm(2).pow(2) +
            self.item_embed.weight.norm(2).pow(2)
        )


# -------------------------------
# RMSE / MAE metrics
# -------------------------------
def evaluate(model, loader):
    model.eval()
    preds, true = [], []

    with torch.no_grad():
        for u, i, r in loader:
            p = model(u, i)
            preds.extend(p.numpy())
            true.extend(r.numpy())

    preds = torch.tensor(preds)
    true = torch.tensor(true)

    rmse = torch.sqrt(torch.mean((preds - true) ** 2)).item()
    mae = torch.mean(torch.abs(preds - true)).item()

    return rmse, mae


# -------------------------------
# Train the best model
# -------------------------------
if __name__ == "__main__":

    # Load dataset
    train_df, test_df, n_users, n_items = load_movielens(
        "ml-100k/u.data"
    )

    train_loader = DataLoader(RatingsDataset(train_df), batch_size=1024, shuffle=True)
    test_loader = DataLoader(RatingsDataset(test_df), batch_size=1024)

    # Best parameters
    embed_dim = 8
    lr = 0.1
    reg = 0.001

    model = MF(n_users, n_items, embed_dim, reg)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    epochs = 10

    for epoch in range(1, epochs + 1):
        model.train()
        for u, i, r in train_loader:
            pred = model(u, i)
            loss = loss_fn(pred, r) + model.l2_regularization()

            opt.zero_grad()
            loss.backward()
            opt.step()

        rmse, mae = evaluate(model, test_loader)
        print(f"Epoch {epoch}: RMSE={rmse:.4f}, MAE={mae:.4f}")

    print("\nTraining complete!")
    print(f"Best Model → Embedding={embed_dim}, LR={lr}, Reg={reg}")
